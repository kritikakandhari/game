"""Pydantic schemas package."""

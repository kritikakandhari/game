"""Repository interfaces package."""

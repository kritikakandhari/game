"""Core application modules."""
from app.core.config import settings

__all__ = ["settings"]

"""FGC Money Match Backend API."""

__version__ = "1.0.0"
